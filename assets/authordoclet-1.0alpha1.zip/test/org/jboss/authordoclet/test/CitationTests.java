/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.test;

import org.jboss.authordoclet.util.XHTMLParser;
import org.jboss.authordoclet.Constants;
import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.anchor.AnchorOption;
import org.jboss.authordoclet.anchor.Scheme;
import static org.testng.Assert.assertEquals;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 *
 */
public class CitationTests {

    XHTMLParser xhtmlParser = new XHTMLParser() {
        public void error(SAXParseException e) throws SAXException {
            throw new RuntimeException("Error parsing XHTML: " + e, e);
        }

        public void fatalError(SAXParseException e) throws SAXException {
            throw new RuntimeException("Error parsing XHTML: " + e, e);
        }
    };

    protected Document doc;

    @BeforeClass
    protected void createDoc() throws Exception {
        doc = xhtmlParser.getFactory().newDocumentBuilder().newDocument();
    }

    @Test
    public void parseCitationTargets() throws Exception {

        Element element = doc.createElement("a");
        element.setAttribute(Constants.ATTR_TYPE, Constants.TYPE_CITATION);
        element.setAttribute(Constants.ATTR_ADDRESS, "javadoc://com.myorg.MyClass.Nested#someMethod(java.util.String[], Integer)");

        Anchor citation = new Anchor(element);
        assertEquals(citation.getId(), null);
        assertEquals(citation.getTitle(), null);
        assertEquals(citation.getOptions(), new AnchorOption[0]);
        assertEquals(citation.getAddress().getScheme(), Scheme.JAVADOC);
        assertEquals(citation.getAddress().getPath(), "com.myorg.MyClass.Nested");
        assertEquals(citation.getAddress().getFragment(), "someMethod(java.util.String[], Integer)");

        element.setAttribute(Constants.ATTR_ADDRESS, "javacode://com.myorg.MyClass");
        citation = new Anchor(element);
        assertEquals(citation.getAddress().getScheme(), Scheme.JAVACODE);
        assertEquals(citation.getAddress().getPath(), "com.myorg.MyClass");
        assertEquals(citation.getAddress().getFragment(), null);

        element.setAttribute(Constants.ATTR_ADDRESS, "javacode://com.myorg");
        citation = new Anchor(element);
        assertEquals(citation.getAddress().getScheme(), Scheme.JAVACODE);
        assertEquals(citation.getAddress().getPath(), "com.myorg");
        assertEquals(citation.getAddress().getFragment(), null);

        element.setAttribute(Constants.ATTR_ADDRESS, "/com/myorg/foo.xhtml");
        citation = new Anchor(element);
        assertEquals(citation.getAddress().getScheme(), Scheme.FILE);
        assertEquals(citation.getAddress().getPath(), "com/myorg/foo.xhtml");
        assertEquals(citation.getAddress().getFragment(), null);

        element.setAttribute(Constants.ATTR_ADDRESS, "com/myorg/bar.txt");
        citation = new Anchor(element);
        assertEquals(citation.getAddress().getScheme(), Scheme.FILE);
        assertEquals(citation.getAddress().getPath(), "com/myorg/bar.txt");
        assertEquals(citation.getAddress().getFragment(), null);
        
        element.setAttribute(Constants.ATTR_ADDRESS, "foo.txt");
        citation = new Anchor(element);
        assertEquals(citation.getAddress().getScheme(), Scheme.FILE);
        assertEquals(citation.getAddress().getPath(), "foo.txt");
        assertEquals(citation.getAddress().getFragment(), null);

    }

    @Test
    public void parseAnchors() throws Exception {

        Element element = doc.createElement("a");
        element.setAttribute(Constants.ATTR_TYPE, Constants.TYPE_CITATION);
        element.setAttribute(Constants.ATTR_ADDRESS, "javadoc://com.myorg.MyClass");
        element.setAttribute(Constants.ATTR_ID, "some.custom.id");
        element.setAttribute(Constants.ATTR_TITLE, "Custom Title");

        Anchor citation = new Anchor(element);
        assertEquals(citation.getId(), "some.custom.id");
        assertEquals(citation.getTitle(), "Custom Title");

        element.setAttribute(Constants.ATTR_OPTIONS, AnchorOption.OPT_READ_TITLE + ": false");
        citation = new Anchor(element);
        assertEquals(citation.getOptions()[0].getKey(), AnchorOption.OPT_READ_TITLE);
        assertEquals(citation.getOptions()[0].isTrue(), false);

        element.setAttribute(Constants.ATTR_OPTIONS, AnchorOption.OPT_READ_TITLE + ": true");
        citation = new Anchor(element);
        assertEquals(citation.getOptions()[0].isTrue(), true);

        element.setAttribute(Constants.ATTR_OPTIONS, AnchorOption.OPT_INCLUDE+ ": F1, F2; " + AnchorOption.OPT_EXCLUDE + ": E1");
        citation = new Anchor(element);
        assertEquals(citation.getOptions()[0].getValues()[0], "F1");
        assertEquals(citation.getOptions()[0].getValues()[1], "F2");
        assertEquals(citation.getOptions()[1].getValues()[0], "E1");

    }

}

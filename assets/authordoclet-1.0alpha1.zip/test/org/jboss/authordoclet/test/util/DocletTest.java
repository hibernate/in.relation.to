/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.test.util;

import com.sun.javadoc.RootDoc;
import org.jboss.authordoclet.util.EasyDoclet;
import org.jboss.authordoclet.util.ReadWriteTextFile;
import org.jboss.authordoclet.util.XHTMLParser;
import org.jboss.authordoclet.pipeline.javadoc.XHTMLTemplateJavadocPipeline;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import java.io.File;
import java.net.URL;

/**
 *
 */
public class DocletTest {

    protected String sourcePath;

    protected Document xmlDocument;

    protected RootDoc rootDoc;

    protected XHTMLParser xhtmlParser = new XHTMLParser() {
        public void error(SAXParseException e) throws SAXException {
            throw new RuntimeException("Error parsing XHTML: " + e, e);
        }

        public void fatalError(SAXParseException e) throws SAXException {
            throw new RuntimeException("Error parsing XHTML: " + e, e);
        }
    };

    protected XHTMLTemplateJavadocPipeline xhtmlTemplatePipeline;

    @BeforeClass
    @Parameters("sourcePath")
    public void init(@Optional String sourcePath) throws Exception {
        this.sourcePath = sourcePath;
        xmlDocument = xhtmlParser.getFactory().newDocumentBuilder().newDocument();
        rootDoc = new EasyDoclet(new File(sourcePath == null ? "" : sourcePath), getPackageNames()).getRootDoc();
        xhtmlTemplatePipeline = new XHTMLTemplateJavadocPipeline(getRootDoc(), sourcePath);
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public String[] getPackageNames() {
        return new String[0];
    }

    public Document getXmlDocument() {
        return xmlDocument;
    }

    public RootDoc getRootDoc() {
        return rootDoc;
    }

    public XHTMLParser getXhtmlParser() {
        return xhtmlParser;
    }

    public XHTMLTemplateJavadocPipeline getXhtmlTemplatePipeline() {
        return xhtmlTemplatePipeline;
    }

    public Document parseDocument(String file) throws Exception {
        return getXhtmlParser().parse(getResource(file));
    }

    public String getContent(String file) throws Exception {
        return ReadWriteTextFile.getContent(new File(getResource(file).toURI()));
    }

    protected URL getResource(String file) {
        URL resource = Thread.currentThread().getContextClassLoader().getResource(file);
        if (resource == null) throw new IllegalArgumentException("Can't find resource on classpath: " + file);
        return resource;
    }

}

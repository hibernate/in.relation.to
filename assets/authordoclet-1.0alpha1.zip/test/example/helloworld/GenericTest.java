/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package example.helloworld;

import com.sun.tools.javac.util.Pair;
import org.jboss.authordoclet.test.util.DocletTest;
import org.jboss.authordoclet.util.XML;
import static org.testng.Assert.assertEquals;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.w3c.dom.Document;

/**
 * Tests that are not documented in the manual but probably should be documented later.
 */
public class GenericTest extends DocletTest {

    @Override
    public String[] getPackageNames() {
        return new String[]{"example"};
    }

    @DataProvider(name = "samples")
    public Object[][] getSamples() {
        return new Object[][]{
                {new Pair<String, String>("example/helloworld/generic01_input.xhtml", "example/helloworld/generic01_output.xhtml")},
                {new Pair<String, String>("example/helloworld/generic02_input.xhtml", "example/helloworld/generic02_output.xhtml")},
                {new Pair<String, String>("example/helloworld/generic03_input.xhtml", "example/helloworld/generic03_output.xhtml")},
                {new Pair<String, String>("example/helloworld/generic04_input.xhtml", "example/helloworld/generic04_output.xhtml")},
                {new Pair<String, String>("example/helloworld/generic06_input.xhtml", "example/helloworld/generic06_output.xhtml")},
        };
    }

    @DataProvider(name = "errorSamples")
    public Object[][] getErrorSamples() {
        return new Object[][]{
                {"example/helloworld/error01_input.xhtml"},
        };
    }

    @Test(dataProvider = "samples")
    public void process(Pair<String, String> sample) throws Exception {

        Document output = getXhtmlTemplatePipeline().execute(parseDocument(sample.fst));
        assertEquals(XML.printPretty(output), getContent(sample.snd));

    }

    @Test(dataProvider = "errorSamples", expectedExceptions = IllegalStateException.class)
    public void processFail(String sample) throws Exception {
        getXhtmlTemplatePipeline().execute(parseDocument(sample));
    }

    /**
     * This is a nested class.
     * <p>
     * And this is its documentation for testing purposes.
     * </p>
     */
    public static class MyNestedClass {

        public class HelloWorld {
            public String getMessage() {
                return "Hello World";
            }
        }

        /**
         * Documentation of the print method.
         * <p>
         * Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vel tellus eros,
         * quis molestie lectus. Integer rutrum imperdiet enim in ullamcorper.
         * </p>

         * @param args The arguments.
         */
        public void printHelloWorld(String[] args) {

            String message = new HelloWorld().getMessage();
            System.out.println(message);

            System.out.println("Arguments: " + args.length);
        }

        public void sayHello() {
            System.out.println("Hello!");
            System.out.println("World!");
        }
    }

}

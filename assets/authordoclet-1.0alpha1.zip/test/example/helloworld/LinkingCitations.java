/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package example.helloworld;

import org.testng.annotations.Test;
import org.jboss.authordoclet.util.XML;
import org.jboss.authordoclet.test.util.DocletTest;
import org.w3c.dom.Document;
import static org.testng.Assert.assertEquals;

/**
 * Creating links to citations
 * <p>
 * AuthorDoclet will recognize any {@code @{link}} tags in your Javadoc comments and try to
 * match them by cross-referencing all your citations for the same Java package, method, or class.
 * Consider the following example:
 * </p>
 * <a class="citation" href="javacode://example.helloworld.LinkingCitations" style="include: FRAG1"/>
 * <p>
 * When you include this Javadoc comment with an AuthorDoclet citation, a regular XHTML anchor will
 * be created automatically. AuthorDoclet will try to match the target of the link to any of your citations.
 * So if you also have a citation of the {@code HelloWorld} class in your manual, the following link
 * will be automatically generated:
 * </p>
 * <a class="citation" href="example/helloworld/example08_output.xhtml" style="include: FRAG1"/>
 * <p>
 * The title of the anchor will match the title of the target - if the target has a title. If neither
 * the target or its title can be found, a warning message will be logged during processing and broken
 * link placeholder will be set in the output XHTML.
 * </p>
 */
public class LinkingCitations extends DocletTest {

    @Override
    public String[] getPackageNames() {
        return new String[]{"example"};
    }

    // DOC: FRAG1
    /**
     * This method calls
     * the {@link HelloWorld} class.
     */
    // DOC: FRAG1
    public void callHelloWorld() {
        new HelloWorld();
    }

    /**
     * This is a broken link to
     * the {@link HelloWorld#getMessage} method
     * followed by {@link HelloWorld#sayHello this link} to the source of
     * another method.
     */
    public void brokenLinks() {
    }

    @Test
    public void processDocumentation() throws Exception {
        Document output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example08_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example08_output.xhtml")
        );
    }

}

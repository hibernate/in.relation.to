/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package example.helloworld;

import org.jboss.authordoclet.test.util.DocletTest;
import org.jboss.authordoclet.util.XML;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import static org.testng.Assert.assertEquals;

/**
 * Customizing citation with anchor options
 * <p>
 * Citation can be customized with options, specified as CSS-like values with the {@code style} attribute
 * of the anchor element.
 * </p>
 * <div class="section">
 * <a class="citation" href="javadoc://example.helloworld.CustomizingAnchorOptions#javadocCustomTitle()">Citation</a>
 * </div>
 * <div class="section">
 * <a class="citation" href="javadoc://example.helloworld.CustomizingAnchorOptions#javacodeFragments()">Citation</a>
 * </div>
 * <div class="section">
 * <a class="citation" href="javadoc://example.helloworld.CustomizingAnchorOptions#javacodeCleanLabels()">Citation</a>
 * </div>
 */
public class CustomizingAnchorOptions extends DocletTest {

    @Override
    public String[] getPackageNames() {
        return new String[]{"example"};
    }

    /**
     * Disabling Javadoc titles
     * <p>
     * When AuthorDoclet reads your Javadoc comment, it will use the "first sentence" (as defined by Javadoc) of the
     * comment as the title of the citation section. For example, {@link HelloWorld the HelloWorld class shown previously}
     * has the first sentence title "Just print a hello.". AuthorDoclet will remove the period at the end of the first
     * sentence automatically. You can disable this behavior with the {@code read-title} option:
     * </p>
     * <a class="citation" href="example/helloworld/example02_input.xhtml" style="include: LABEL">Citation</a>
     * <p>
     * Your Javadoc comment is now cited as it is, with no special treatment of the "first sentence". Alternatively,
     * you can use the {@code title} attribute of the anchor to override any "first sentence" title:
     * </p>
     * <a class="citation" href="example/helloworld/example03_input.xhtml" style="include: LABEL">Citation</a>
     */
    @Test
    public void javadocCustomTitle() throws Exception {
        Document output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example02_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example02_output.xhtml")
        );

        output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example03_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example03_output.xhtml")
        );
    }

    /**
     * Including and excluding Javacode fragments
     * <p>
     * A {@code javacode://} citation which references a Java package, class, or method, will by default
     * include all lines of code of that package, class, or method. Very often you only want a fragment of the
     * code lines cited. First, you have to declare the fragments with line comments in your Java source file:
     * </p>
     * <a class="citation" href="javacode://example.helloworld.HelloWorld" id="javacode_HelloWorld_raw" style="clean-labels: false">Citation</a>
     * <p>
     * Within this Java source file, three fragments have been declared. The first two fragment are multi-line block
     * fragments, the third is a single-line fragment. The rules are: A line comment starting with a {@code // DOC:} prefix marks
     * the beginning of a fragment. The {@code DOC:} prefix is followed by a <em>fragment label</em>, which has to
     * match the following regular expression: {@code [A-Z_-]+[0-9]*} If the label is not repeated in a subsequent
     * line, the fragment only includes a single line. If the label is repeated in a subsequent line, all lines in
     * between and including the labeled lines are considered part of the same multi-line fragment block. A fragment
     * label comment can be placed in an empty line or at the end of a line, after content you wish to include in
     * the fragment.
     * </p>
     * <p>
     * You can now use the labeled fragments to selectively include and/or exclude content in citations:
     * </p>
     * <a class="citation" href="example/helloworld/example04_input.xhtml" style="include: LABEL">Citation</a>
     * <p>
     * This citation only includes the two named fragments, producing the following output:
     * </p>
     * <a class="citation" href="example/helloworld/example04_output.xhtml" style="include: LABEL;">Citation</a>
     * <p>
     * Exclusion of fragments occurs after inclusion, as the following example demonstrates:
     * </p>
     * <a class="citation" href="example/helloworld/example05_input.xhtml" style="include: LABEL">Citation</a>
     * <p>
     * The excluded fragment is now missing from the output:
     * </p>
     * <a class="citation" href="example/helloworld/example05_output.xhtml" style="include: LABEL;">Citation</a>
     */
    @Test
    public void javacodeFragments() throws Exception {
        Document output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example04_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example04_output.xhtml")
        );

        output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example05_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example05_output.xhtml")
        );
    }

    /**
     * Removing fragment labels
     * <p>
     * AuthorDoclet will automatically remove any fragment labels - the specially formatted comments - from cited
     * content. It is sometimes useful, for example to document the actual usage of AuthorDoclet, to keep the
     * fragment labels in a piece of cited source code. For example, given the same {@code HelloWorld} class marked
     * with three fragments from the previous example, the following citation would preserve the labels:
     * </p>
     * <a class="citation" href="example/helloworld/example06_input.xhtml" style="include: LABEL">Citation</a>
     * <p>
     * This produces the following output:
     * </p>
     * <a class="citation" href="example/helloworld/example06_output.xhtml" style="include: LABEL;">Citation</a>
     * <p>
     * As a special case, you can also preserve only the fragment labels within a fragment block, and still
     * remove the labels that defined the actual fragment block:
     * </p>
     * <a class="citation" href="example/helloworld/example07_input.xhtml" style="include: LABEL">Citation</a>
     * <a class="citation" href="example/helloworld/example07_output.xhtml" style="include: LABEL;">Citation</a>
     */
    @Test
    public void javacodeCleanLabels() throws Exception {
        Document output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example06_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example06_output.xhtml")
        );

        output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example07_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example07_output.xhtml")
        );
    }

}

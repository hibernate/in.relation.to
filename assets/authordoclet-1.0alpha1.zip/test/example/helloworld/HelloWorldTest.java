/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package example.helloworld;

import org.jboss.authordoclet.test.util.DocletTest;
import org.jboss.authordoclet.util.XML;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import static org.testng.Assert.assertEquals;

/**
 * Hello World: Creating testable documentation
 * <p>
 * Let's assume you want to test <em>and</em> document the following {@code HelloWorld} Java class:
 * </p>
 * <a class="citation" href="javacode://example.helloworld.HelloWorld">Citation</a>
 * <p>
 * First, write a unit test method that checks the class:
 * </p>
 * <a class="citation" href="javacode://example.helloworld.HelloWorldTest#testHelloWorld()">Citation</a>
 * <p>
 * This unit test not only validates the correct behavior of the class, it also shows how the class is
 * supposed to be used. Traditionally, you'd now add a section in your software's manual, where you copy and
 * paste the code of the {@code HelloWorld} class and some lines from the unit test. Your users will
 * then be able to understand the internals and how they should work with the class.
 * </p>
 * <p>
 * With AuthorDoclet you don't copy/paste anything but write documentation as Javadoc on the test method in XHTML syntax:
 * </p>
 * <a class="citation" href="javacode://example.helloworld.HelloWorldTest" style="include: TEST_HELLOWORLD; clean-labels: boundary;">Citation</a>
 * <p>
 * You probably already know all of the XHTML elements and attributes used in this Javadoc comment, in fact, you can
 * use any tags you need to write your documentation. AuthorDoclet parses your markup and replaces the content of
 * {@code <a>} elements that have a {@code citation} class. The first anchor in the example above is
 * referencing the raw Java source code of a class called {@code example.helloworld.HelloWorld}. How this source
 * code is found by AuthorDoclet depends on your configuration, we'll look at that later. Note how the URI scheme
 * {@code javacode://} is used to indicate what part of the referenced resource you want to cite. This URL is actually
 * refactoring-safe, your IDE should be able to automatically update the URI string when you rename the package or
 * {@code HelloWorld} class name.
 * </p>
 * <p>
 * The second anchor is more specific, it's a citation for a fragment of code. The URL references the source of the
 * test class and the test method (yes, it's referencing "itself"). You'll probably recognize the method reference syntax
 * from Javadoc, it's the same as for regular Javadoc {@code @link} and {@code @see} tags, hence also safe for
 * refactoring. Citation options are declared with the {@code style} attribute, they look like CSS options. The
 * {@code include} option shown here accepts a list of fragment labels which should be cited. A fragment label is
 * a Java line comment starting with "{@code // DOC: (LABEL)}". Two lines with the same label mark the beginning and end
 * of a fragment block. So this citation will only include the four lines of the method body. You'll later see more
 * details about citation options, fragments, and labels.
 * </p>
 * <p>
 * The previous Javadoc represents just one small section of your overall documentation. AuthorDoclet's default processing
 * pipeline expects that you also create a master template file in XHTML that brings together all of your documentation
 * parts, chapters, and sections. How that template looks like, and how parts, chapters, and sections are organized and
 * finally rendered is up to you. Here is a simple example of a template:
 * </p>
 * <a class="citation" href="example/helloworld/example01_input.xhtml">Citation</a>
 * <p>
 * Note that the URL scheme for this citation is {@code javadoc://}. The AuthorDoclet processor will follow the URL
 * to your test class and test method, and then read and process the Javadoc comment of that resource. This is a recursive
 * procedure, so any citation anchors in the Javadoc comment are followed and processed as well. Finally, the following output
 * is generated:
 * </p>
 * <a class="citation" href="example/helloworld/example01_output.xhtml">Citation</a>
 * <p>
 * The formatting and indentation of this XHTML document has been automatically generated by a pretty printer, so it
 * readability could obvioulsy be improved. All Javadoc code fragments have been properly escaped in CDATA sections. All
 * cited source fragments have been escaped with XHTML entities instead (future versions of AuthorDoclet will likely embed
 * XHTML markup for callouts into code blocks, hence they are not defined as CDATA sections).
 * </p>
 * <p>
 * This is how it looks rendered in a browser:
 * </p>
 * <img src="doc-files/helloworld_rendered_output.png" border="1"/>
 * <p>
 * You can execute AuthorDoclet from the command-line:
 * </p>
 * <pre class="code">{@code
 * java -jar authordoclet.jar [options]
 *
 * -i <template.xhtml>   : XHTML template file.
 * -o <result.xhtml>     : XHTML output file.
 * -overwrite true|false : Overwrite existing output file quietly.
 * -p <package.name>     : Included package, repeat option for multiple packages.
 * -s <path>             : The base path of all source files.
 *}</pre>
 *
 */
public class HelloWorldTest extends DocletTest {

    @Override
    public String[] getPackageNames() {
        return new String[]{"example"};
    }

    // DOC: TEST_HELLOWORLD
    /**
     * The {@code HelloWorld} class
     * <p>
     * This is the source of the class:
     * </p>
     *
     * <a class="citation"
          href="javacode://example.helloworld.HelloWorld"/>
     *
     * <p>
     * To use the class, first instantiate it, then call either {@code getMessage()} to retrieve
     * the message string or {@code sayHello()} to print the message to {@code System.out}:
     * </p>
     *
     * <a class="citation"
          href="javacode://example.helloworld.HelloWorldTest#testHelloWorld()"
          style="include: HELLOWORLD_USAGE;"/>
     *
     * <p>
     * If you don't want the message printed to {@code System.out}, don't call the
     * {@code sayHello()} method.
     * </p>
     */
    @Test
    public void testHelloWorld() {
        HelloWorld hw = new HelloWorld();                   // DOC: HELLOWORLD_USAGE
        assert hw.getMessage().equals("Hello World!");
        assert hw.getMessage().endsWith("!");
        hw.sayHello();                                      // DOC: HELLOWORLD_USAGE
    }
    // DOC: TEST_HELLOWORLD

    @Test
    public void processDocumentation() throws Exception {
        Document output = getXhtmlTemplatePipeline().execute(
                parseDocument("example/helloworld/example01_input.xhtml")
        );

        assertEquals(
                XML.printPretty(output),
                getContent("example/helloworld/example01_output.xhtml")
        );
    }
}

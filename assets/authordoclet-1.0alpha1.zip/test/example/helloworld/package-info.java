/**
 * This is package documentation.
 * <p>
 * Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vel tellus eros,
 * quis molestie lectus. Integer rutrum imperdiet enim in ullamcorper.
 * </p>
 */
package example.helloworld;
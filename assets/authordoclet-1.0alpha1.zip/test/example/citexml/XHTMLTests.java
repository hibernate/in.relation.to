/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package example.citexml;

import static org.testng.Assert.assertEquals;
import org.jboss.authordoclet.util.XML;
import org.jboss.authordoclet.test.util.DocletTest;
import org.w3c.dom.Document;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import com.sun.tools.javac.util.Pair;

/**
 *
 */
public class XHTMLTests extends DocletTest {


    @DataProvider(name = "samples")
    public Object[][] getSamples() {
        return new Object[][]{
                {new Pair<String, String>("example/citexml/sample01_input.xhtml", "example/citexml/sample01_output.xhtml")},
                {new Pair<String, String>("example/citexml/sample02_input.xhtml", "example/citexml/sample02_output.xhtml")},
        };
    }

    @Override
    public String[] getPackageNames() {
        return new String[]{"example.helloworld"};
    }

    @Test(dataProvider = "samples")
    public void process(Pair<String, String> sample) throws Exception {

        Document output = getXhtmlTemplatePipeline().execute(parseDocument(sample.fst));
        assertEquals(XML.printPretty(output), getContent(sample.snd));

    }


}

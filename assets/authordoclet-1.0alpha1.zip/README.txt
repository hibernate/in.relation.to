
                            AuthorDoclet

What is it?
============

AuthorDoclet simplifies and facilitates the creation of validated Java software
documentation, at the source and unit test level.

Usage
============

Please consult the manual in /doc/manual.xhtml.

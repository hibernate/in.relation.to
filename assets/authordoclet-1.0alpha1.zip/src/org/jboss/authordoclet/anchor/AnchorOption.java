/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.anchor;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/**
 *
 */
public class AnchorOption {

    public static final String OPT_READ_TITLE = "read-title";
    public static final String OPT_INCLUDE = "include";
    public static final String OPT_EXCLUDE = "exclude";
    public static final String OPT_CLEAN_LABELS = "clean-labels";
    public static final String OPT_LTRIM = "ltrim";
    public static final String OPT_READER = "reader";

    private String key;
    private String[] values;

    public AnchorOption(String key, String[] values) {
        this.key = key;
        this.values = values;
    }

    public String getKey() {
        return key;
    }

    public String[] getValues() {
        return values;
    }

    public boolean isTrue() {
        return getValues().length == 1 && getValues()[0].toLowerCase().equals("true");
    }

    public boolean isFalse() {
        return getValues().length == 1 && getValues()[0].toLowerCase().equals("false");
    }

    public String getFirstValue() {
        return getValues()[0];
    }

    public static AnchorOption[] fromString(String string) {
        if (string == null || string.length() == 0) return new AnchorOption[0];

        List<AnchorOption> options = new ArrayList();

        try {

            String[] fields = string.split(";");
            for (String field : fields) {

                field = field.trim();
                String[] keyValues = field.split(":");
                String key = keyValues[0].trim();
                String[] values = keyValues[1].split(",");
                for (int i = 0; i < values.length; i++) {
                    values[i] = values[i].trim();
                }

                options.add(new AnchorOption(key, values));
            }

            return options.toArray(new AnchorOption[options.size()]);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Can't parse anchor options string: " + string, ex);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getKey()).append(": ");
        Iterator<String> it = Arrays.asList(getValues()).iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if(it.hasNext())sb.append(", ");
        }
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AnchorOption that = (AnchorOption) o;

        if (!key.equals(that.key)) return false;
        if (!Arrays.equals(values, that.values)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = key.hashCode();
        result = 31 * result + Arrays.hashCode(values);
        return result;
    }
}

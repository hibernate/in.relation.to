/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.anchor;

import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.SeeTag;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Logger;

/**
 *
 */
public class AnchorAddress {

    final private static Logger log = Logger.getLogger(AnchorAddress.class.getName());

    public static final Pattern PATTERN =
            Pattern.compile("^([a-zA-Z]+?)://([\\p{Alnum}\\./_-]+?)(?:#([\\p{Alnum}]+?\\([\\p{Alnum},\\.\\[\\]<>\\s]*?\\)))??$");

    final private Scheme scheme;
    final private String path;
    final private String fragment;

    public AnchorAddress(Scheme scheme, String path, String fragment) {
        if (path == null || path.length() == 0) {
            throw new IllegalArgumentException("Reference path can not be empty");
        }
        this.scheme = scheme;
        this.path = path;
        this.fragment = fragment;
    }

    public Scheme getScheme() {
        return scheme;
    }

    public String getPath() {
        return path;
    }

    public String getFragment() {
        return fragment;
    }

    public static AnchorAddress fromString(String string) {
        if (string == null || string.length() == 0) return null;

        // Try to match the string as an AnchorAddress, if it doesn't then convert it to file:// address and try again
        Matcher m = PATTERN.matcher(string.trim());
        if (!m.matches()) {
            String fileString = toFileAddress(string);
            log.finest("Address string does not contain a schema, using file schema: " + fileString);
            m.reset(fileString);
            if (!m.matches()) {
                throw new IllegalArgumentException("Invalid reference: " + string);
            }
        }
        return new AnchorAddress(Scheme.valueOf(m.group(1).toUpperCase()), m.group(2), m.group(3));
    }

    public static AnchorAddress fromTag(Scheme scheme, SeeTag tag) {
        String reference = null;
        if (tag.referencedMember() != null && tag.referencedMember().isMethod()) {
            reference = tag.referencedClassName() + "#" +
                    tag.referencedMember().name() +
                    ((MethodDoc)tag.referencedMember()).flatSignature();
        } else if (tag.referencedClass() != null) {
            reference = tag.referencedClassName();
        } else if (tag.referencedPackage() != null) {
            reference = tag.referencedPackage().name();
        }

        return reference != null
                ? fromString(scheme.name().toLowerCase() + Scheme.SEPARATOR + reference)
                : null;
    }

    public static String toFileAddress(String string) {
        if (string.startsWith(".")) throw new IllegalArgumentException("Reference can't start with a period '.'");

        // Always remove leading and trailing slashes
        if (string.startsWith("/")) string = string.substring(1);
        if (string.endsWith("/")) string = string.substring(0, string.length()-1);

        return Scheme.FILE + Scheme.SEPARATOR + string;
    }

    // This is an XSD:ID
    public String toIdentifierString() {

        String schemeString = getScheme().name().toLowerCase();
        String pathString = getPath();
        String fragmentString = (getFragment() != null ? "#" + getFragment() : "");

        return (schemeString + "." + pathString + fragmentString)
                .replaceAll("\\s", "")
                .replaceAll("#|,", ".")
                .replaceAll("\\[|\\]", "-")
                .replaceAll("\\(|\\)", ".")
                .replaceAll("[^a-zA-Z0-9-._]", "_")
                .replaceAll("__", "_");
    }

/*
    public boolean isMatching(SeeTag tag) {
        // Is the referenced class/member/package of this tag the same as the target of this citation?
        if (tag.referencedPackage() != null) {
            if (!getPath().equals(tag.referencedPackage().name()) || getFragment() != null) {
                return false;
            }
        }
        if (tag.referencedClass() != null) {
            if (!getPath().equals(tag.referencedClassName())) {
                return false;
            }
        }
        if (tag.referencedMember() != null) {
            if (getFragment() == null || !getFragment().equals(tag.referencedMemberName())) {
                return false;
            }
        }
        return true;
    }
*/

    @Override
    public String toString() {
        return getScheme().name().toLowerCase() + Scheme.SEPARATOR + getPath() + (getFragment() != null ? "#" + getFragment() : "");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AnchorAddress that = (AnchorAddress) o;

        if (fragment != null ? !fragment.equals(that.fragment) : that.fragment != null) return false;
        if (!path.equals(that.path)) return false;
        if (scheme != that.scheme) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = scheme.hashCode();
        result = 31 * result + path.hashCode();
        result = 31 * result + (fragment != null ? fragment.hashCode() : 0);
        return result;
    }
}

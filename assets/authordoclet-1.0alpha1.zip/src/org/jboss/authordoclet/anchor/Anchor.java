/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.anchor;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.jboss.authordoclet.Constants;

import java.util.Iterator;
import java.util.Arrays;

/**
 *
 */
public class Anchor {

    private String type;
    private String id;
    private String title;
    private String textContent;
    private AnchorAddress address;
    private AnchorOption[] options;

    public Anchor(Element element) {
        this(element.getAttribute(Constants.ATTR_TYPE),
                element.getAttribute(Constants.ATTR_ID),
                element.getAttribute(Constants.ATTR_TITLE),
                element.getTextContent(),
                AnchorAddress.fromString(element.getAttribute(Constants.ATTR_ADDRESS)),
                AnchorOption.fromString(element.getAttribute(Constants.ATTR_OPTIONS))
        );
    }


    public Anchor(String type, String id, String title, String textContent, AnchorAddress address, AnchorOption[] options) {
        this.type = "".equals(type) ? null : type;
        this.id = "".equals(id) ? null : id;
        this.title = "".equals(title) ? null : title;
        this.textContent = "".equals(textContent) ? null : textContent;
        this.address = address;
        this.options = options;
    }

    public String getType() {
        return type;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getTextContent() {
        return textContent;
    }

    public AnchorAddress getAddress() {
        return address;
    }

    public AnchorOption[] getOptions() {
        return options;
    }

    public AnchorOption getOption(String key) {
        for (AnchorOption option : getOptions()) {
            if (option.getKey().equals(key)) return option;
        }
        return null;
    }

    public String getOptionsAsString() {
        StringBuilder sb = new StringBuilder();
        Iterator<AnchorOption> it = Arrays.asList(getOptions()).iterator();
        while (it.hasNext()) {
            sb.append(it.next().toString());
            if(it.hasNext())sb.append("; ");
        }
        return sb.toString();
    }

    public String getOutputIdentifier() {
        return getId() != null ? getId() : getAddress().toIdentifierString();
    }

    public String getOutputClasses() {
        return getType() + " " + getAddress().getScheme().name().toLowerCase();
    }

    public String[][] getAttributes() {
        return new String[][] {
                getType() != null ? new String[] { Constants.ATTR_TYPE, getType()} : null,
                getId() != null ? new String[] { Constants.ATTR_ID, getId()} : null,
                getTitle() != null ? new String[] { Constants.ATTR_TITLE, getTitle()} : null,
                getAddress() != null ? new String[] { Constants.ATTR_ADDRESS, getAddress().toString()} : null,
                getOptions() != null ? new String[] { Constants.ATTR_OPTIONS, getOptionsAsString()} : null
        };
    }

    public Element toElement(Document document) {
        Element el = document.createElement(Constants.ANCHOR_ELEMENT_NAME);
        if (getType() != null)
            el.setAttribute(Constants.ATTR_TYPE, getType());
        if (getId() != null)
            el.setAttribute(Constants.ATTR_ID, getId());
        if (getTitle() != null)
            el.setAttribute(Constants.ATTR_TITLE, getTitle());
        if (getTextContent() != null)
            el.setTextContent(getTextContent());
        if (getAddress() != null)
            el.setAttribute(Constants.ATTR_ADDRESS, getAddress().toString());
        if (getOptions() != null)
            el.setAttribute(Constants.ATTR_OPTIONS, getOptionsAsString());
        return el;
    }

    @Override
    public String toString() {
        return "(" + getClass().getSimpleName() + ") " + getAddress();
    }

}

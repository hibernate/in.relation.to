/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.pipeline.javadoc;

import com.sun.javadoc.PackageDoc;
import com.sun.javadoc.RootDoc;
import org.jboss.authordoclet.pipeline.Pipeline;
import org.jboss.authordoclet.processor.Processor;
import org.jboss.authordoclet.processor.xhtml.JavadocCitationProcessor;
import org.jboss.authordoclet.processor.xhtml.XRefProcessor;
import org.jboss.authordoclet.processor.xhtml.TocProcessor;
import org.jboss.authordoclet.reader.javadoc.AbstractJavadocReader;
import org.jboss.authordoclet.reader.xml.XMLReader;
import org.jboss.authordoclet.reader.javacode.JavacodeRawReader;
import org.jboss.authordoclet.util.EasyDoclet;
import org.jboss.authordoclet.util.ReadWriteTextFile;
import org.jboss.authordoclet.util.XHTMLParser;
import org.jboss.authordoclet.util.XML;
import org.kohsuke.args4j.Argument;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import org.w3c.dom.Document;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 *
 */
public class XHTMLTemplateJavadocPipeline extends Pipeline<Document, Document> {

    final private Logger log = Logger.getLogger(XHTMLTemplateJavadocPipeline.class.getName());

    final private XHTMLParser xhtmlParser = XHTMLParser.newInstance();

    final private RootDoc rootDoc;
    final private String basePath;
    final private boolean normalizeOutput;
    final private boolean removeIgnorableWhitespace;

    public XHTMLTemplateJavadocPipeline(File basePath, Collection<String> packageNames) {
        this(new EasyDoclet(basePath, packageNames).getRootDoc(), basePath.getAbsolutePath(), true, true);
    }

    public XHTMLTemplateJavadocPipeline(RootDoc rootDoc, String basePath) {
        this(rootDoc, basePath, true, true);
    }

    public XHTMLTemplateJavadocPipeline(RootDoc rootDoc, String basePath,
                                        boolean normalizeOutput, boolean removeIgnorableWhitespace) {
        log.info("Configuring pipeline with base path: " + basePath);
        for (PackageDoc packageDoc : rootDoc.specifiedPackages()) {
            log.info("Included package: " + packageDoc);
        }
        this.rootDoc = rootDoc;
        this.basePath = basePath;
        this.normalizeOutput = normalizeOutput;
        this.removeIgnorableWhitespace = removeIgnorableWhitespace;
    }

    public RootDoc getRootDoc() {
        return rootDoc;
    }

    public String getBasePath() {
        return basePath;
    }

    public boolean isNormalizeOutput() {
        return normalizeOutput;
    }

    public boolean isRemoveIgnorableWhitespace() {
        return removeIgnorableWhitespace;
    }

    protected Document execute(File xhtmlTemplateFile) {
        Document template;
        try {
            log.info("Parsing initial XHTML template file: " + xhtmlTemplateFile);
            template = xhtmlParser.parse(xhtmlTemplateFile.toURI().toURL());
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        return execute(template);
    }

    @Override
    protected void resetContext() {
        super.resetContext();
        getContext().put(AbstractJavadocReader.CONTEXT_ROOT_DOC, getRootDoc());
        getContext().put(XMLReader.CONTEXT_BASE_PATH, getBasePath());
        getContext().put(JavacodeRawReader.CONTEXT_BASE_PATH, getBasePath());
    }

    @Override
    public Document execute(Document input) {
        Document output = super.execute(input);

        if (isNormalizeOutput())
            output.normalizeDocument();

        if (isRemoveIgnorableWhitespace())
            XML.removeIgnorableWSNodes(output.getDocumentElement());

        log.info("Processing complete!");
        return output;
    }

    public Processor<Document, Document>[] getProcessors() {
        return new Processor[]{
                new JavadocCitationProcessor(getRootDoc()),
                new XRefProcessor(),
                new TocProcessor(),
        };
    }

    public static void main(String[] args) throws Exception {

        // Load the default logging configuration
        if (System.getProperty("java.util.logging.config.file") == null) {
            LogManager.getLogManager().readConfiguration(Pipeline.class.getResourceAsStream("/logging.properties"));
        }

        Options options = new Options();
        CmdLineParser cmdLineParser = new CmdLineParser(options);
        try {
            cmdLineParser.parseArgument(args);
        } catch (CmdLineException e) {
            System.err.println(e.getMessage());
            System.err.println("USAGE: java -jar authordoclet.jar [options]");
            cmdLineParser.printUsage(System.err);
            return;
        }

        if (!options.sourcePath.exists()) {
            System.err.println("Source path not found: " + options.sourcePath);
            return;
        }

        if (!options.xhtmlTemplateFile.exists()) {
            System.err.println("XHTML template file not found: " + options.sourcePath);
            return;
        }

        XHTMLTemplateJavadocPipeline pipeline = new XHTMLTemplateJavadocPipeline(options.sourcePath, options.packageNames);

        Document result = pipeline.execute(options.xhtmlTemplateFile);

        pipeline.prepareOutputFile(options.xhtmlOutputFile, options.overwriteOutputFile);

        System.out.println("Writing output file: " + options.xhtmlOutputFile.getAbsolutePath());

        ReadWriteTextFile.setContent(
                options.xhtmlOutputFile,
                XML.printPretty(result, true, 4) // TODO: Make configurable?
        );
    }

    public static class Options {

        @Option(required = true, name = "-s", metaVar = "<path>", usage =
                "The base path of all source files.")
        File sourcePath;

        @Option(required = true, name = "-p", metaVar = "<package.name>", multiValued = true,
                usage = "Included package, repeat option for multiple packages.")
        List<String> packageNames = new ArrayList();

        @Option(required = true, name = "-i", metaVar = "<template.xhtml>",
                usage = "XHTML template file.")
        File xhtmlTemplateFile;

        @Option(required = true, name = "-o", metaVar = "<result.xhtml>",
                usage = "XHTML output file.")
        File xhtmlOutputFile;

        @Option(name = "-overwrite", metaVar = "true|false", usage = "Overwrite existing output file quietly.")
        boolean overwriteOutputFile = false;

        @Argument
        List<String> arguments = new ArrayList();
    }

}

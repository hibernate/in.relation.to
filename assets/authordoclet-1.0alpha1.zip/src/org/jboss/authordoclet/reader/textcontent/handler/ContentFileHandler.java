/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.reader.textcontent.handler;

import org.jboss.authordoclet.reader.textcontent.LineRange;
import org.jboss.authordoclet.util.ReadWriteTextFile;

import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.logging.Logger;
import java.io.File;

/**
 *
 */
public class ContentFileHandler {

    final private Logger log = Logger.getLogger(ContentFileHandler.class.getName());

    final private Map<File, String[]> cache = new HashMap();

    public String[] getContent(File file, LineRange range) {
        try {

            String[] content;

            synchronized (cache) {
                if (cache.containsKey(file)) {
                    log.fine("Using cached content lines of file: " + file.getName());
                    content = cache.get(file);
                } else {
                    log.fine("Reading content lines from file on disk: " + file);
                    content = ReadWriteTextFile.getContent(file).split("\n");
                    cache.put(file, content);
                }
            }

            if (range != null) {
                log.fine("Returning content line range " + range + " of file: " + file.getName());
                return Arrays.copyOfRange(content, range.getBegin()- 1, range.getEnd());
            } else {
                return content;
            }

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

    }

}

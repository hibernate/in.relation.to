/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.reader.textcontent.filter;

import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.anchor.AnchorOption;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.logging.Logger;

/**
 *
 */
public class FragmentFilter extends AbstractContentFilter {

    final private Logger log = Logger.getLogger(FragmentFilter.class.getName());

    final private Pattern fragmentLabelPattern;

    public FragmentFilter(Pattern fragmentLabelPattern) {
        this.fragmentLabelPattern = fragmentLabelPattern;
    }

    public Pattern getFragmentLabelPattern() {
        return fragmentLabelPattern;
    }

    public String[] process(String[] source, Anchor citation) {

        if (source == null || source.length == 0) return source;

        AnchorOption includeOption = citation.getOption(AnchorOption.OPT_INCLUDE);
        AnchorOption excludeOption = citation.getOption(AnchorOption.OPT_EXCLUDE);
        String[] includeFragments = includeOption != null ? includeOption.getValues() : new String[0];
        String[] excludeFragments = excludeOption != null ? excludeOption.getValues() : new String[0];

        log.fine("Filtering " + source.length + " source lines, included/excluded fragments: "
                + includeFragments.length + "/" + excludeFragments.length);

        List<Integer> includedLines = new ArrayList();

        if (includeFragments.length == 0) {
            // Include ALL
            for (int i = 0; i < source.length; i++) {
                includedLines.add(i);
            }
        } else {
            // Include fragment blocks
            includedLines.addAll(getFragmentLines(source, includeFragments));
        }

        // Exclude fragment blocks
        List<Integer> excludedLines = getFragmentLines(source, excludeFragments);

        List<String> filtered = new ArrayList();

        for (int i = 0; i < source.length; i++) {
            String s = source[i];
            if (includedLines.contains(i) && !excludedLines.contains(i)) {
                filtered.add(s);
            }
        }
        return filtered.toArray(new String[filtered.size()]);
    }

    protected List<Integer> getFragmentLines(String[] source, String[] fragments) {
        List<Integer> lines = new ArrayList();

        // Include only lines that are inside a block that BEGINs/ENDs with a fragment label; as
        // a special case, non-closed blocks are also supported for the most common case when
        // only a single line is actually marked.

        for (String fragment : fragments) {

            List<Integer> fragmentLines = new ArrayList();
            boolean inBlock = false;
            int lastBegin = 0;

            for (int line = 0; line < source.length; line++) {

                String s = source[line];
                if (isLineMatchingFragment(s, fragment)) {
                    if (!inBlock) {
                        // BEGIN the block demarcated by the fragment label
                        inBlock = true;
                        lastBegin = line;
                    } else {
                        // END the block demarcated by the fragment label
                        inBlock = false;
                        // Add last line of block
                        fragmentLines.add(line);
                    }
                }

                // If we are inside a BEGIN/END fragment block, add the line
                if (inBlock) {
                    fragmentLines.add(line);
                }

                // If the last block was not ENDed and we have reached the end, roll back to the
                // last BEGIN but include that line. In other words: Enable single-line blocks
                if (line == source.length - 1 && inBlock) {
                    Iterator<Integer> it = fragmentLines.iterator();
                    while (it.hasNext()) {
                        if (it.next() > lastBegin) it.remove();
                    }
                }
            }
            lines.addAll(fragmentLines);
        }
        return lines;
    }

    protected boolean isLineMatchingFragment(String line, String fragment) {
        Matcher m = getFragmentLabelPattern().matcher(line);
        return m.matches() && m.group(2).equals(fragment);
    }

}

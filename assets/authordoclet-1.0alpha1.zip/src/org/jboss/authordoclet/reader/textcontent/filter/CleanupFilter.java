/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.reader.textcontent.filter;

import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.anchor.AnchorOption;
import org.jboss.authordoclet.util.XML;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 */
public class CleanupFilter extends AbstractContentFilter {

    final private Logger log = Logger.getLogger(CleanupFilter.class.getName());

    final private Pattern fragmentLabelPattern;

    public CleanupFilter(Pattern fragmentLabelPattern) {
        this.fragmentLabelPattern = fragmentLabelPattern;
    }

    public Pattern getFragmentLabelPattern() {
        return fragmentLabelPattern;
    }

    public String[] process(String[] source, Anchor citation) {
        if (source == null || source.length == 0) return source;

        log.fine("Cleaning (removing labels, whitespace, escaping) source lines: " + source.length);
        List<String> cleanLines = new ArrayList();

        // Count whitespaces of first line
        String firstline = source[0];
        int spaces = 0;
        while (firstline.matches("^\\s+.*")) {
            firstline = firstline.substring(1);
            spaces++;
        }

        for (int i = 0; i < source.length; i++) {
            String line = source[i];

            // Remove fragment label from line, or remove the whole line
            AnchorOption cleanLabelsOption = citation.getOption(AnchorOption.OPT_CLEAN_LABELS);
            if (cleanLabelsOption == null || cleanLabelsOption.isTrue()) {
                line = removeFragmentComment(line);
                if (line == null) continue;
            }

            // Remove fragment label from line, or remove whole line, if it's the first or last line (boundary of fragment)
            if (cleanLabelsOption != null && cleanLabelsOption.getFirstValue() != null
                    && cleanLabelsOption.getFirstValue().toLowerCase().equals("boundary")
                    && (i == 0 || i == source.length-1)) {
                line = removeFragmentComment(line);
                if (line == null) continue;
            }

            AnchorOption ltrimOption = citation.getOption(AnchorOption.OPT_LTRIM);
            if (ltrimOption == null || ltrimOption.isTrue()) {
                // Remove white spaces from beginning of line (if there are that many spaces at the beginning of the line)
                line = line.length() > spaces && line.matches("^\\s{"+spaces+",}.*") ? line.substring(spaces) : line;
            }


            // Escape XHTML reserved characters
            line = XML.escape(line);

            cleanLines.add(line);
        }

        return cleanLines.toArray(new String[cleanLines.size()]);
    }

    protected String removeFragmentComment(String line) {
        Matcher m = getFragmentLabelPattern().matcher(line);
        if (m.matches()) {
            String cleanLine = m.group(1);

            // Remove trailing whitespace then return remaining before-comment text
            while(cleanLine.matches(".*( |\\t)$")) {
                cleanLine = cleanLine.substring(0, cleanLine.length()-1);
            }

            // Well if nothing is left, we remove the whole line (returning null does that)
            return cleanLine.length() == 0 ? null : cleanLine;
        }
        return line;
    }

}
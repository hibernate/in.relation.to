/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.reader.javadoc;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.Doc;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.RootDoc;
import org.jboss.authordoclet.Context;
import org.jboss.authordoclet.reader.AbstractReader;
import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.anchor.Scheme;
import org.w3c.dom.Document;

import java.util.logging.Logger;

/**
 *
 */
public abstract class AbstractJavadocReader extends AbstractReader {

    final private Logger log = Logger.getLogger(AbstractJavadocReader.class.getName());

    final public static String CONTEXT_ROOT_DOC = " JavadocReader.rootDoc";

    public Document read(Anchor citation, Context context) {
        RootDoc rootDoc = (RootDoc)context.get(CONTEXT_ROOT_DOC);
        if (rootDoc == null) {
            throw new IllegalStateException("Missing root Javadoc in context, can't read Javadoc");
        }
        return read(citation, context, rootDoc);
    }

    protected abstract Document read(Anchor citation, Context context, RootDoc rootDoc);

    protected Doc findTargetDoc(Anchor citation, RootDoc rootDoc) {

        if (!(citation.getAddress().getScheme().equals(Scheme.JAVADOC) ||
                citation.getAddress().getScheme().equals(Scheme.JAVACODE))) {
            throw new RuntimeException("TODO: NO SUPPORT FOR file://some/JavaClass.java ADDRESSES!");
        }

        // Try package name first
        Doc targetDoc = rootDoc.packageNamed(citation.getAddress().getPath());
        if (targetDoc == null) {

            // Now try class name
            targetDoc = rootDoc.classNamed(citation.getAddress().getPath());

            // Get method doc for signature (both qualified and flat are attempted)
            // TODO: This might not guarantee a hit because we only check qualified names syntactially, not semantically
            String fragment = citation.getAddress().getFragment();
            if (targetDoc != null && fragment != null) {

                MethodDoc[] methodDocs = ((ClassDoc) targetDoc).methods();
                targetDoc = null;

                log.finest("Trying to find matching signature for citation target fragment: " + fragment);
                for (MethodDoc methodDoc : methodDocs) {
                    String qualifiedSignature = methodDoc.name() + methodDoc.signature();
                    String unqualifiedSignature = methodDoc.name() + methodDoc.flatSignature();
                    if (qualifiedSignature.equals(fragment) || unqualifiedSignature.equals(fragment)) {
                        log.finest("Found method with matching signature: " + methodDoc.position());
                        targetDoc = methodDoc;
                        break;
                    }
                }

            }
        }

        if (targetDoc == null) {
            throw new IllegalArgumentException("Target not found in Javadoc unit: " + citation);
        }
        return targetDoc;
    }

}

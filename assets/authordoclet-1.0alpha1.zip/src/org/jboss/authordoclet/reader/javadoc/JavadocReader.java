/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.reader.javadoc;

import com.sun.javadoc.Doc;
import com.sun.javadoc.RootDoc;
import com.sun.javadoc.SeeTag;
import com.sun.javadoc.Tag;
import org.jboss.authordoclet.util.XML;
import org.jboss.authordoclet.util.Text;
import org.jboss.authordoclet.Constants;
import org.jboss.authordoclet.Context;
import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.anchor.AnchorAddress;
import org.jboss.authordoclet.anchor.AnchorOption;
import org.jboss.authordoclet.anchor.Scheme;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.logging.Logger;

/**
 *
 */
public class JavadocReader extends AbstractJavadocReader {

    final private Logger log = Logger.getLogger(JavadocReader.class.getName());

    protected Document read(Anchor citation, Context context, RootDoc rootDoc) {
        return read(
                findTargetDoc(citation, rootDoc),
                citation
        );
    }

    protected Document read(Doc doc, Anchor citation) {

        log.fine("Reading Javadoc: " + doc.position());

        String titleString = readTitle(doc, citation);

        Element titleElement =
                titleString != null ?
                        getXhtmlParser().wrap(
                                Constants.WRAPPER_ELEMENT_NAME,
                                new String[][]{new String[]{Constants.ATTR_TYPE, Constants.TYPE_TITLE}},
                                titleString
                        ).getDocumentElement()
                        : null;

        Element contentElement = readContent(doc, citation, titleString);

        if (contentElement == null && titleElement == null) {
            log.warning("No Javadoc found for: " + citation);
        }

        // Wrap everything up
        return wrap(citation, titleElement, contentElement);
    }

    protected String readTitle(Doc doc, Anchor citation) {

        // We only add a title if the first sentence is a single "Text" tag because links in
        // document titles is not something we'd want
        String text = citation.getTitle();
        AnchorOption readTitleOption = citation.getOption(AnchorOption.OPT_READ_TITLE);
        if ((readTitleOption == null || readTitleOption.isTrue()) && text == null) {
            if (doc.firstSentenceTags().length > 0) {
                text = readTags(doc.firstSentenceTags());
            }
        }
        return text;
    }

    protected Element readContent(Doc doc, Anchor citation, String titleString) {

        String content = readTags(doc.inlineTags());

        // Cut off the title if we already have it
        if (titleString != null && content.startsWith(titleString)) {
            content = content.substring(titleString.length());
        }

        Element contentElement = null;

        if (content.length() > 0) {
            // Make it look pretty
            String text = Text.ltrim(Text.rtrim(content));

            contentElement = getXhtmlParser().wrap(
                    Constants.WRAPPER_ELEMENT_NAME,
                    new String[][]{new String[]{Constants.ATTR_TYPE, Constants.TYPE_CONTENT}},
                    text
            ).getDocumentElement();

        } else {
            log.fine("Citation does not have a content element: " + citation);
        }

        return contentElement;
    }

    protected String readTags(Tag[] tags) {
        StringBuilder content = new StringBuilder();
        for (Tag tag : tags) {

            if (tag.kind().equals("Text")) {

                content.append(readTagText(tag));

            } else if (tag.kind().equals("@see")) {

                content.append(readTagSee((SeeTag)tag));

            } else if (tag.kind().equals("@code") || tag.kind().equals("@literal")) {

                content.append(readTagCode(tag));

            } else {
                log.warning("Skipping unknown tag of kind: " + tag.kind());
            }
        }
        return content.toString();
    }

    protected String readTagText(Tag tag) {
        log.finest("Reading inline text tag");
        return tag.text();
    }

    protected String readTagSee(SeeTag seeTag) {
        log.finest("Reading inline link tag");

        AnchorAddress xref;
        if ((xref = getLinkReferenceAddress(seeTag)) != null) {
            return getLinkReference(seeTag, xref);
        } else {
            return getLinkLabel(seeTag);
        }
    }

    protected String readTagCode(Tag tag) {
        log.finest("Reading code/literal tag");
        StringBuilder content = new StringBuilder();
        // If it's an inline {@code} tag with no newlines in its text, we wrap the text in a <tt> element
        boolean inlineCode = !tag.text().contains("\n");
        if (inlineCode) content.append("<code>");
        content.append(Constants.CDATA_BEGIN);
        content.append(tag.text());
        content.append(Constants.CDATA_END);
        if (inlineCode) content.append("</code>");
        return content.toString();
    }

    protected AnchorAddress getLinkReferenceAddress(SeeTag tag) {
        // TODO: Always javadoc:// scheme?
        return AnchorAddress.fromTag(Scheme.JAVADOC, tag);
    }

    protected String getLinkReference(SeeTag tag, AnchorAddress address) {
        Anchor xrefAnchor = new Anchor(Constants.TYPE_XREF, null, null, tag.label(), address, null);
        Document d = getXhtmlParser().wrap(
                Constants.ANCHOR_ELEMENT_NAME,
                xrefAnchor.getAttributes(),
                tag.label()
        );
        return XML.toString(d, false);
    }

    protected String getLinkLabel(SeeTag tag) {
        String referencedLabel;
        if (tag.referencedMember() != null) {
            referencedLabel = tag.referencedClassName() + "#" + tag.referencedMemberName();
        } else if (tag.referencedClass() != null) {
            referencedLabel = tag.referencedClassName();
        } else if (tag.referencedPackage() != null) {
            referencedLabel = tag.referencedPackage().name();
        } else {
            throw new IllegalStateException("Reference not found: " + tag + " at " + tag.position());
        }

        if (tag.label() != null && tag.label().length() > 0) {
            return tag.label() + " (" + referencedLabel + ")";
        } else {
            return referencedLabel;
        }
    }

}

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.reader.xml;

import org.jboss.authordoclet.Constants;
import org.jboss.authordoclet.Context;
import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.reader.AbstractReader;
import org.jboss.authordoclet.reader.textcontent.handler.ContentFileHandler;
import org.jboss.authordoclet.reader.textcontent.printer.ContentPrinter;
import org.jboss.authordoclet.reader.textcontent.filter.CleanupFilter;
import org.jboss.authordoclet.reader.textcontent.filter.ContentFilter;
import org.jboss.authordoclet.reader.textcontent.filter.FragmentFilter;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 */
public class XMLReader extends AbstractReader {

    final private Logger log = Logger.getLogger(XMLReader.class.getName());

    final public static String CONTEXT_BASE_PATH = "XMLReader.basePath";

    final public static Pattern PATTERN_FRAGMENT_LABEL =
            Pattern.compile("(.*?)[\\t ]*<!--[\\t ]*" + Constants.PATTERN_FRAGMENT_LABEL + "[\\t ]*-->$");

    final protected ContentFileHandler handler;
    final protected ContentPrinter printer;
    final protected ContentFilter[] filters;

    public XMLReader() {
        handler = new ContentFileHandler();
        printer = new ContentPrinter();
        filters = new ContentFilter[]{
                new FragmentFilter(PATTERN_FRAGMENT_LABEL),
                new CleanupFilter(PATTERN_FRAGMENT_LABEL)
        };
    }

    public Document read(Anchor citation, Context context) {

        String absolutePath = getAbsolutePath(citation, context, CONTEXT_BASE_PATH);
        log.fine("Including and parsing XHTML file: " + absolutePath);

        Element titleElement = readTitle(citation);
        Element contentElement = readContent(absolutePath, citation);

        if (contentElement == null && titleElement == null) {
            log.warning("No title or content found for: " + citation);
        }

        return wrap(citation, titleElement, contentElement);
    }

    protected Element readContent(String filePath, Anchor citation) {

        String[] content = handler.getContent(new File(filePath), null);

        // Filtering of source
        for (ContentFilter filter : filters) {
            content = filter.process(content, citation);
        }

        // Transform the source into an XML document
        String contentOutput = printer.print(content);
        if (contentOutput != null) {
            return getXhtmlParser().wrap(
                    Constants.WRAPPER_ELEMENT_NAME,
                    new String[][]{new String[]{Constants.ATTR_TYPE, Constants.TYPE_CONTENT}},
                    contentOutput
            ).getDocumentElement();
        }
        return null;
    }

}

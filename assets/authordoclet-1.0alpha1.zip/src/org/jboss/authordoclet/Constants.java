/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet;

import java.util.regex.Pattern;

/**
 *
 */
public interface Constants {

    public static final String PATTERN_FRAGMENT_LABEL = "DOC:\\s*([A-Z_-]+[0-9]*)\\s*";

    public static final String CDATA_BEGIN = "<![CDATA[";
    public static final String CDATA_END = "]]>";

    public static final String WRAPPER_ELEMENT_NAME = "div";

    public static final String ANCHOR_ELEMENT_NAME = "a";

    public static final String TYPE_CITATION = "citation";
    public static final String TYPE_XREF = "xref";
    public static final String TYPE_TITLE = "title";
    public static final String TYPE_CONTENT = "content";
    public static final String TYPE_UNRESOLVED = "unresolved";

    public static final String ATTR_TYPE = "class";
    public static final String ATTR_ID = "id";
    public static final String ATTR_NAME = "name";
    public static final String ATTR_TITLE = "title";
    public static final String ATTR_ADDRESS = "href";
    public static final String ATTR_OPTIONS = "style";
    

}

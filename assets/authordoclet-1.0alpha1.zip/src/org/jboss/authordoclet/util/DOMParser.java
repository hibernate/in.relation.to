/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.logging.Logger;
import java.io.StringReader;

/**
 * Condensed API for parsing of XML into DOM with (optional) XML schema validation.
 *
 * @author Christian Bauer
 */
public abstract class DOMParser implements ErrorHandler {

    private static Logger log = Logger.getLogger(DOMParser.class.getName());

    public static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";

    public static final URI XML_SCHEMA_NAMESPACE = URI.create("http://www.w3.org/2001/xml.xsd");
    public static final URL XML_SCHEMA_RESOURCE = Thread.currentThread().getContextClassLoader().getResource("org/jboss/authordoclet/schemas/xml.xsd");

    protected final Schema schema;
    protected final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    public DOMParser() {
        try {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            schemaFactory.setResourceResolver(new CatalogResourceResolver(
                    new HashMap<URI, URL>() {{
                        put(XML_SCHEMA_NAMESPACE, XML_SCHEMA_RESOURCE);
                    }}
            ));

            schema = schemaFactory.newSchema(getSchemaSources());
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

    }

    protected abstract Source[] getSchemaSources();

    public DocumentBuilderFactory getFactory() {
        return factory;
    }

    public Document newDocument() {
        try {
            return getFactory().newDocumentBuilder().newDocument();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public void validate(URL url) throws Exception {
        if (url == null) throw new IllegalArgumentException("Can't validate null URL");

        log.fine("Validating XML document: " + url);
        Validator validator = schema.newValidator();
        validator.setErrorHandler(this);
        Source source = new StreamSource(url.toString());
        validator.validate(source);
    }

    public void validate(String xml) throws Exception {
        log.fine("Validating XML document");
        Validator validator = schema.newValidator();
        validator.setErrorHandler(this);
        validator.validate(new SAXSource(new InputSource(new StringReader(xml)))); // I love this API!
    }

    public Document parse(URL url) throws Exception {
        return parse(url, true);
    }

    public Document parse(URL url, boolean validate) throws Exception {
        if (url == null) throw new IllegalArgumentException("Can't parse null URL");

        if (validate) validate(url);

        log.fine("Parsing XML document into DOM: " + url);
        DocumentBuilder parser = factory.newDocumentBuilder();

        // TODO: Can't use an InputStream as input, JDK 6 is buggy: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6506304
        Document dom = parser.parse(url.toString());
        dom.normalizeDocument();
        return dom;
    }

    public Document parse(String string) throws RuntimeException {
        return parse(string, true);
    }

    public Document parse(String string, boolean validate) throws RuntimeException {
        try {
/*
            System.out.println("------------------------------------------------------------------------------------");
            System.out.println(string);
            System.out.println("------------------------------------------------------------------------------------");
*/
            if (validate) validate(string);
            
            DocumentBuilder parser = factory.newDocumentBuilder();
            Document dom = parser.parse(new InputSource(new StringReader(string)));
            dom.normalizeDocument();
            return dom;
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public Document wrap(String element, String[][] attributes) throws RuntimeException {
        return wrap(element, attributes, "");
    }

    public Document wrap(String element, String[][] attributes, Element... children) throws RuntimeException {
        Document doc = wrap(element, attributes);
        if (children != null) {
            for (Element child: children) {
                if (child != null)
                    doc.getDocumentElement().appendChild(doc.adoptNode(child));
            }
        }
        return doc;
    }

    public Document wrap(String element, String[][] attributes, String fragment) throws RuntimeException {
        StringBuilder wrapper = startWrapperElement(element, attributes);
        wrapper.append(fragment);
        wrapper.append("</").append(element).append(">");
        return parse(wrapper.toString(), false);
    }


    protected StringBuilder startWrapperElement(String wrapperElement, String[][] wrapperAttributes) {
        StringBuilder wrapper = new StringBuilder();
        wrapper.append("<").append(wrapperElement);
        if (wrapperAttributes != null) {
            for (String[] wrapperAttribute : wrapperAttributes) {
                if (wrapperAttribute == null) continue;
                if (wrapperAttribute.length != 2) {
                    throw new IllegalArgumentException(("Wrapper attributes argument must be key/value pairs"));
                }
                String key = wrapperAttribute[0];
                String value = wrapperAttribute[1];
                wrapper.append(" ").append(key).append("=\"").append(value).append("\"");
            }
        }
        wrapper.append(">");
        return wrapper;
    }

    public void warning(SAXParseException e) throws SAXException {
        log.warning(e.toString());
    }
    
}

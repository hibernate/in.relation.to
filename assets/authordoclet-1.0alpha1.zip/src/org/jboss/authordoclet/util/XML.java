/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.StringWriter;
import java.io.StringReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.List;
import java.util.ArrayList;

/**
 *
 */
public class XML {

    public static String printPretty(Document dom) {
        return makePretty(toString(dom));
    }

    public static String printPretty(Document dom, int indent) {
        return makePretty(toString(dom), indent);
    }

    public static String printPretty(Document dom, boolean standalone, int indent) {
        return makePretty(toString(dom, standalone), indent);
    }

    public static String toString(Document dom) {
        return toString(dom, true);
    }

    public static String toString(Document dom, boolean standalone) {
        try {
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, standalone ? "no" : "yes");
            StringWriter out = new StringWriter();
            transformer.transform(new DOMSource(dom), new StreamResult(out));
            return out.toString();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public static String makePretty(String input) {
        return makePretty(input, 4);
    }

    public static String makePretty(String input, int indent) {
        if (input == null || input.length() == 0) return "";
        try {
            Source xmlInput = new StreamSource(new StringReader(input));
            StringWriter stringWriter = new StringWriter();
            StreamResult xmlOutput = new StreamResult(stringWriter);
            TransformerFactory transFactory = TransformerFactory.newInstance();

            transFactory.setAttribute("indent-number", indent);

            Transformer transformer = transFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");

            transformer.transform(xmlInput, xmlOutput);
            return xmlOutput.getWriter().toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String escape(String string) {
        return escape(string, false, false);
    }

    public static String escape(String string, boolean convertNewlines, boolean convertSpaces) {
        if (string == null) return null;
        StringBuilder sb = new StringBuilder();
        String htmlEntity;
        char c;
        for (int i = 0; i < string.length(); ++i) {
            htmlEntity = null;
            c = string.charAt(i);
            switch (c) {
                case '<':
                    htmlEntity = "&#60;";
                    break;
                case '>':
                    htmlEntity = "&#62;";
                    break;
                case '&':
                    htmlEntity = "&#38;";
                    break;
                case '"':
                    htmlEntity = "&#34;";
                    break;
            }
            if (htmlEntity != null) {
                sb.append(htmlEntity);
            } else {
                sb.append(c);
            }
        }
        String result = sb.toString();
        if (convertSpaces) {
            // Converts the _beginning_ of line whitespaces into non-breaking spaces
            Matcher matcher = Pattern.compile("(\\n+)(\\s*)(.*)").matcher(result);
            StringBuffer temp = new StringBuffer();
            while (matcher.find()) {
                String group = matcher.group(2);
                StringBuilder spaces = new StringBuilder();
                for (int i = 0; i < group.length(); i++) {
                    spaces.append("&#160;");
                }
                matcher.appendReplacement(temp, "$1" + spaces.toString() + "$3");
            }
            matcher.appendTail(temp);
            result = temp.toString();
        }
        if (convertNewlines) {
            result = result.replaceAll("\n", "<br/>");
        }
        return result;
    }

    public static String removeElements(String original) {
        if (original == null) return null;
        return original.replaceAll("\\<([a-zA-Z]|/){1}?.*?\\>", "");
    }

    public static void removeIgnorableWSNodes(Element parent) {
        Node nextNode = parent.getFirstChild();
        for (Node child = parent.getFirstChild(); nextNode != null;) {
            child = nextNode;
            nextNode = child.getNextSibling();
            if (isIgnorableWSNode(child)) {
                parent.removeChild(child);
            } else if (child.getNodeType() == Node.ELEMENT_NODE) {
                removeIgnorableWSNodes((Element) child);
            }
        }
    }

    public static boolean isIgnorableWSNode(Node node) {
        return node.getNodeType() == Node.TEXT_NODE &&
            node.getTextContent().matches("[\\t\\n\\x0B\\f\\r\\s]+");
    }

    public static List<Element> getAllElements(Node parent) {
        List<Element> nodes = new ArrayList();
        addChildren(Node.ELEMENT_NODE, parent, nodes);
        return nodes;
    }

    public static List<Node> getAllComments(Node parent) {
        List<Node> nodes = new ArrayList();
        addChildren(Node.COMMENT_NODE, parent, nodes);
        return nodes;
    }

    protected static void addChildren(short nodeType, Node parent, List nodes) {
        NodeList children = parent.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == nodeType) {
                nodes.add(child);
            }
            addChildren(nodeType, child, nodes);
        }
    }

    public static void removeChildren(Node node) {
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            node.removeChild(child);
        }
    }

    public static void removeChildRecursive(Node node, Node child) {
        NodeList children = node.getChildNodes();
        boolean foundChild = false;
        for (int i = 0; i < children.getLength(); i++) {
            foundChild = children.item(i).equals(child);
            removeChildRecursive(children.item(i), child);
        }
        if (foundChild)
            node.removeChild(child);
    }

}

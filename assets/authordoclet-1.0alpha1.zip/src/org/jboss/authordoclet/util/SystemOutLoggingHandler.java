/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.logging.StreamHandler;
import java.util.logging.Level;

/**
 * Clean one-line log output to <tt>System.out</tt>.
 *
 * @author Christian Bauer
 */
public class SystemOutLoggingHandler extends StreamHandler {

    public SystemOutLoggingHandler() {
        super(System.out,
                new Formatter() {

                    public String format(LogRecord record) {
                        StringBuffer buf = new StringBuffer(180);
                        DateFormat dateFormat = new SimpleDateFormat("kk:mm:ss,SS");

                        buf.append("[").append(Thread.currentThread().getName()).append("] ");
                        buf.append(record.getLevel());
                        buf.append(" - ");
                        buf.append(dateFormat.format(new Date(record.getMillis())));
                        buf.append(" - ");
                        buf.append(record.getSourceClassName());
                        buf.append('.');
                        buf.append(record.getSourceMethodName());
                        buf.append(": ");
                        buf.append(formatMessage(record));

                        buf.append("\n");

                        Throwable throwable = record.getThrown();
                        if (throwable != null) {
                            StringWriter sink = new StringWriter();
                            throwable.printStackTrace(new PrintWriter(sink, true));
                            buf.append(sink.toString());
                        }

                        return buf.toString();
                    }

                }
        );
        setLevel(Level.ALL);
    }

    public void close() {
        flush();
    }

    public void publish(LogRecord record) {
        super.publish(record);
        flush();
    }

}

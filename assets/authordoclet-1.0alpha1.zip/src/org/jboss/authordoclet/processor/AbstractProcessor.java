/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.processor;

import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.anchor.AnchorOption;
import org.jboss.authordoclet.anchor.Scheme;
import org.jboss.authordoclet.reader.javacode.JavacodeRawReader;
import org.jboss.authordoclet.reader.javacode.JavacodeReader;
import org.jboss.authordoclet.reader.PlaintextReader;
import org.jboss.authordoclet.reader.Reader;
import org.jboss.authordoclet.reader.javadoc.JavadocReader;
import org.jboss.authordoclet.reader.xml.XMLReader;
import org.jboss.authordoclet.Constants;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 *
 */
public abstract class AbstractProcessor<IN, OUT> implements Processor<IN, OUT> {

    final protected Map<String, Class<? extends Reader>> READER_SUFFIX_MAP =
            new HashMap<String, Class<? extends Reader>>() {{
                put(".java", JavacodeRawReader.class);
                put(".html", XMLReader.class);
                put(".xhtml", XMLReader.class);
                put(".xml", XMLReader.class);
                put(".txt", PlaintextReader.class);
                put(".csv", PlaintextReader.class);
            }};

    final private Map<Class<? extends Reader>, Reader> readerCache = new HashMap();

    public Reader getReader(Anchor citation) {

        Class<? extends Reader> readerType = null;
        AnchorOption readerOption = citation.getOption(AnchorOption.OPT_READER);

        if (readerOption == null && !citation.getAddress().getScheme().equals(Scheme.FILE)) {

            switch(citation.getAddress().getScheme()) {
                case JAVADOC:
                    return new JavadocReader();
                case JAVACODE:
                    return new JavacodeReader();
                default:
                    throw new IllegalStateException("No reader availablef or address scheme of: " + citation);
            }

        } else if (readerOption != null) {

            try {
                readerType = (Class<? extends Reader>) Thread.currentThread()
                        .getContextClassLoader()
                        .loadClass(readerOption.getFirstValue());
            } catch (Exception ex) {
                throw new RuntimeException("Unknown reader type: " + readerOption.getFirstValue(), ex);
            }

        } else {

            // Try a suffix match
            for (Map.Entry<String, Class<? extends Reader>> entry : READER_SUFFIX_MAP.entrySet()) {
                if (citation.getAddress().getPath().endsWith(entry.getKey())) {
                    readerType = entry.getValue();
                }
            }

        }
        
        if (readerType == null)
            throw new IllegalStateException("Unconfigured and/or unknown reader type for: " + citation);

        if (!readerCache.containsKey(readerType)) {
            try {
                Reader reader = readerType.newInstance();
                readerCache.put(readerType, reader);
            } catch (Exception ex) {
                throw new RuntimeException("Can't instantiate reader type: " + readerType, ex);
            }
        }

        return readerCache.get(readerType);
    }

    protected Map<Element, Anchor> findAnchors(Document input, String type) {
        List<Element> elements = findElements(input, Constants.ANCHOR_ELEMENT_NAME, type);
        Map<Element, Anchor> anchorMap = new LinkedHashMap(); // Order!
        for (Element element : elements) {
            Anchor anchor = new Anchor(element);
            if (type == null || type.equals(anchor.getType()))
                anchorMap.put(element, anchor);
        }
        return anchorMap;
    }

    protected List<Element> findElements(Document input, String elementName, String type) {
        return findElements(input.getElementsByTagName(elementName), elementName, type);
    }

    protected List<Element> findElements(NodeList input, String type) {
        return findElements(input, null, type);
    }

    protected List<Element> findElements(NodeList input, String elementName, String type) {
        List<Element> elements = new ArrayList();
        for (int i = 0; i < input.getLength(); i++) {
            Node node = input.item(i);
            if (node.getNodeType() != (Node.ELEMENT_NODE))
                continue;
            if (elementName != null && !node.getNodeName().equals(elementName))
                continue;
            Element element = (Element)node;
            if (type != null) {
                String[] types = element.getAttribute(Constants.ATTR_TYPE).split(" ");
                for (String t : types) {
                    if (t.trim().equals(type))
                        elements.add(element);
                }
            } else {
                elements.add(element);
            }
        }
        return elements;
    }

}

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.processor.xhtml;

import com.sun.tools.javac.util.Pair;
import org.jboss.authordoclet.Constants;
import org.jboss.authordoclet.Context;
import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.processor.AbstractProcessor;
import org.jboss.authordoclet.util.XHTMLParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 *
 */
public class TocProcessor extends AbstractProcessor<Document, Document> {

    private Logger log = Logger.getLogger(TocProcessor.class.getName());

    public static final String TYPE_TOC = "toc";
    public static final String TYPE_TOC_ITEM = "tocitem";
    public static final String TYPE_TOC_ITEM_PREFIX = "prefix";
    public static final String TYPE_TOC_ITEM_LEVEL = "level_";
    public static final String SECTION_ELEMENT = "div";
    public static final String[] SECTION_TYPES = {"part", "chapter", "section", "sect1", "sect2", "sect3"}; // Make configurable

    final private XHTMLParser xhtmlParser = XHTMLParser.newInstance();

    public XHTMLParser getXhtmlParser() {
        return xhtmlParser;
    }

    public Document process(Document input, Context context) {
        log.fine("Processing input...");

        Document output = addTableOfContents(input, context);
/*
        if (log.isLoggable(Level.FINEST)) {
            log.finest("Completed processing input, generated output: ");
            log.finest("--------------------------------------------------------------------------------");
            log.finest(XML.toString(output, false));
            log.finest("--------------------------------------------------------------------------------");
        }
*/
        return output;
    }

    protected Document addTableOfContents(Document input, Context context) {

        Map<Element, Anchor> tocAnchors = findAnchors(input, TYPE_TOC);
        if (tocAnchors.size() == 0)
            return input;

        NodeList bodyElements = input.getElementsByTagName("body");
        if (bodyElements.getLength() != 1) {
            log.info("Body element not found, skipping TOC generation");
            return input;
        }

        // Build the TOC tree by appending TocItems to the root item, starting from the XHTML body element
        TocItem rootItem = new TocItem();
        addChildTocItems(rootItem, (Element) bodyElements.item(0));
        Element toc = generateToc(input, rootItem);

        for (Map.Entry<Element, Anchor> entry : tocAnchors.entrySet()) {
            Anchor tocAnchor = entry.getValue();
            // Now swap the placeholder element actual TOC element

            Element original = entry.getKey();
            Node replacement = original.getOwnerDocument().importNode(toc, true);
            original.getParentNode().replaceChild(replacement, original);
        }

        return input;
    }

    protected void addChildTocItems(TocItem currentTocItem, Element currentElement) {

        // Find all children that are section elements (e.g. all chapter/section div's)
        List<Pair<String, Element>> sectionElements = new ArrayList();
        for (int i = 0; i < currentElement.getChildNodes().getLength(); i++) {
            Node node = currentElement.getChildNodes().item(i);
            if (node.getNodeType() != (Node.ELEMENT_NODE))
                continue;
            if (!node.getNodeName().equals(SECTION_ELEMENT))
                continue;
            Element element = (Element)node;

            boolean isSection = false;
            String[] types = element.getAttribute(Constants.ATTR_TYPE).split(" ");
            for (String sectionType : SECTION_TYPES) {
                for (String t : types) {
                    if (t.trim().equals(sectionType)) {
                        isSection = true;
                        break;
                    }
                }
                if (isSection) {
                    sectionElements.add(new Pair<String, Element>(sectionType, element));
                    break;
                }
            }
        }

        // Create TOC items as needed for each section
        if (sectionElements.size() > 0) {
            for (Pair<String, Element> pair: sectionElements) {

                String sectionType = pair.fst;
                Element sectionElement = pair.snd;

                log.finest("Analyzing section element of type: " + sectionType);

                // First, we need an identifier so we can link to the TOC item
                String id = findNearestIdentifier(sectionElement);

                // A title would be nice, so we can modify it later with a TOC number prefix
                Element titleElement = findNearestTitleElement(sectionElement);

                // If we don't have them...
                if (id == null || titleElement == null) {
                    log.info("Skipping section element, no id or title found: " + sectionType);
                    // Don't create a TOC item but continue down the tree within this section
                    addChildTocItems(currentTocItem, sectionElement);
                    continue;
                }

                // If we have them, create the TOC item and link it into the TOC tree
                TocItem sectionTocItem = new TocItem(currentTocItem.level + 1, sectionType, id, titleElement);
                sectionTocItem.parent = currentTocItem;
                currentTocItem.children.add(sectionTocItem);

                // Recursion
                addChildTocItems(sectionTocItem, sectionElement);
            }
        } else {
            // Recursion (only for child elements)
            NodeList children = currentElement.getChildNodes();
            for (int i = 0; i < children.getLength(); i++) {
                Node child = children.item(i);
                if (child.getNodeType() != (Node.ELEMENT_NODE))
                    continue;
                addChildTocItems(currentTocItem, (Element) child);
            }
        }
    }

    protected String findNearestIdentifier(Element sectionElement) {
        String id = sectionElement.getAttribute(Constants.ATTR_ID);

        // If no identifier was specified, we look for a child that was a citation, and take its identifier
        if (id.length() == 0) {
            List<Element> childCitations =
                    findElements(
                            sectionElement.getChildNodes(),
                            Constants.WRAPPER_ELEMENT_NAME,
                            Constants.TYPE_CITATION
                    );
            if (childCitations.size() > 0) {
                Element firstCitation = childCitations.iterator().next();
                id = firstCitation.getAttribute(Constants.ATTR_ID);
            }
        }
        return id == null || id.length() == 0 ? null : id;
    }

    protected Element findNearestTitleElement(Element sectionElement) {

        // Immediate child element
        List<Element> titleElements =
                findElements(
                        sectionElement.getChildNodes(),
                        Constants.WRAPPER_ELEMENT_NAME,
                        Constants.TYPE_TITLE
                );

        // If not found, look for a title child of the first citation child
        if (titleElements.size() == 0) {
            List<Element> childCitations =
                    findElements(
                            sectionElement.getChildNodes(),
                            Constants.WRAPPER_ELEMENT_NAME,
                            Constants.TYPE_CITATION
                    );
            if (childCitations.size() > 0) {
                titleElements =
                        findElements(
                                childCitations.iterator().next().getChildNodes(),
                                Constants.WRAPPER_ELEMENT_NAME,
                                Constants.TYPE_TITLE
                        );
            }
        }

        return titleElements.size() > 0 ? titleElements.iterator().next() : null;
    }

    protected Element generateToc(Document ownerDocument, TocItem root) {
        Element tocElement = ownerDocument.createElement(Constants.WRAPPER_ELEMENT_NAME);
        tocElement.setAttribute(Constants.ATTR_TYPE, TYPE_TOC);
        for (int i = 0; i < root.children.size(); i++) {
            TocItem child = root.children.get(i);
            child.generate(ownerDocument, tocElement, "", i);
        }
        return tocElement;
    }

    protected class TocItem {
        int level;
        String levelName;
        String id;
        Element titleElement;
        List<TocItem> children = new ArrayList();
        TocItem parent;

        public TocItem() {
        }

        public TocItem(int level, String levelName, String id, Element titleElement) {
            this.level = level;
            this.levelName = levelName;
            this.id = id;
            this.titleElement = titleElement;
        }

        public void generate(Document ownerDocument, Element parentElement, String numberPrefix, int number) {

            // TODO: This is all very quick + dirty

            Element itemElement = ownerDocument.createElement(Constants.WRAPPER_ELEMENT_NAME);
            parentElement.appendChild(itemElement);

            itemElement.setAttribute(
                    Constants.ATTR_TYPE, TYPE_TOC_ITEM + " " + TYPE_TOC_ITEM_LEVEL + level + " " + TYPE_TOC_ITEM_LEVEL + levelName
            );

            Element prefixElement = ownerDocument.createElement(Constants.WRAPPER_ELEMENT_NAME);
            itemElement.appendChild(prefixElement);
            String prefixedNumber = numberPrefix + (number+1) + ".";
            prefixElement.setAttribute(Constants.ATTR_TYPE, TYPE_TOC_ITEM_PREFIX);
            prefixElement.setTextContent(prefixedNumber);

            Element anchorElement = ownerDocument.createElement(Constants.ANCHOR_ELEMENT_NAME);
            itemElement.appendChild(anchorElement);
            anchorElement.setTextContent(titleElement.getTextContent());
            anchorElement.setAttribute(Constants.ATTR_ADDRESS, "#"+id);

            titleElement.setTextContent(prefixedNumber + " " + titleElement.getTextContent());

            for (int i = 0; i < children.size(); i++) {
                TocItem child = children.get(i);
                child.generate(ownerDocument, parentElement, prefixedNumber, i);
            }
        }

        // TODO: This is debug code
        public void print() {
            for (int i = 0; i < level; i++) {
                System.out.print("-");
            }
            System.out.println(" " + toString());
            for (TocItem child : children) {
                child.print();
            }
        }

        @Override
        public String toString() {
            return "LEVEL " + level + " TITLE: " + (titleElement != null ? titleElement.getTextContent() : "NULL");
        }
    }
}

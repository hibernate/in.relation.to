/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.processor.xhtml;

import com.sun.javadoc.RootDoc;
import org.jboss.authordoclet.util.XML;
import org.jboss.authordoclet.Constants;
import org.jboss.authordoclet.Context;
import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.processor.AbstractJavadocProcessor;
import org.jboss.authordoclet.reader.Reader;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.Map;
import java.util.Stack;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Logger;

/**
 *
 */
public class JavadocCitationProcessor extends AbstractJavadocProcessor<Document, Document> {

    private Logger log = Logger.getLogger(JavadocCitationProcessor.class.getName());

    public JavadocCitationProcessor(RootDoc rootDoc) {
        super(rootDoc);
    }

    public Document process(Document input, Context context) {
        log.fine("Processing input...");

        Document output = processCitations(context, input, new Stack<Anchor>());

/*
        if (log.isLoggable(Level.FINEST)) {
            log.finest("Completed processing input, generated output: ");
            log.finest("--------------------------------------------------------------------------------");
            log.finest(XML.toString(output, false));
            log.finest("--------------------------------------------------------------------------------");
        }
*/

        checkDuplicateIdentifiers(output);

        return output;
    }

    protected void checkDuplicateIdentifiers(Document document) {

        Set<String> identifiers = new HashSet();
        List<Element> allElements = XML.getAllElements(document.getDocumentElement());
        for (Element element : allElements) {
            String id = element.getAttribute(Constants.ATTR_ID);
            if (!"".equals(id)) {
                if (identifiers.contains(id)) {
                    throw new IllegalStateException("Duplicate identifier, override/change value: " + id);
                }
                identifiers.add(id);
            }
        }
    }

    protected Document processCitations(Context context, Document input, Stack<Anchor> stack) {
        Map<Element, Anchor> anchors = findAnchors(input, Constants.TYPE_CITATION);

        for (Map.Entry<Element, Anchor> entry : anchors.entrySet()) {
            Anchor citation = entry.getValue();
            if (citation.getAddress() == null) continue;

            // Use a stack to detect circular references
            if (stack.contains(citation)) {
                throw new IllegalStateException("Circular citations, remove: " + citation);
            }

            log.fine("Start processing: " + citation);
            stack.push(citation);

            Reader reader = getReader(citation);
            Document result = reader.read(citation, context);

            if (result == null) {
                log.warning("Reader '" + reader.getClass() + "' did not produce a result for: " + citation);
                continue;
            }

            // Parse it again recursively!
            result = processCitations(context, result, stack);

            // Now swap the citation element with the result root element
            Element original = entry.getKey();
            Element replacement = result.getDocumentElement();

            input.adoptNode(replacement);
            original.getParentNode().replaceChild(replacement, original);

            log.fine("Completed processing: " + citation);
            stack.pop();
        }

        return input;
    }


}
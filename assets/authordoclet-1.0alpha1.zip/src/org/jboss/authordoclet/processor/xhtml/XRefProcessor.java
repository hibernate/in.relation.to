/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2000 - 2010, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jboss.authordoclet.processor.xhtml;

import org.jboss.authordoclet.Constants;
import org.jboss.authordoclet.Context;
import org.jboss.authordoclet.anchor.Anchor;
import org.jboss.authordoclet.anchor.AnchorAddress;
import org.jboss.authordoclet.anchor.Scheme;
import org.jboss.authordoclet.processor.AbstractProcessor;
import org.jboss.authordoclet.util.XML;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 *
 */
public class XRefProcessor extends AbstractProcessor<Document, Document> {

    private Logger log = Logger.getLogger(XRefProcessor.class.getName());

    public Document process(Document input, Context context) {
        log.fine("Processing input...");

        Document output = transformReferences(input, context);

/*
        if (log.isLoggable(Level.FINEST)) {
            log.finest("Completed processing input, generated output: ");
            log.finest("--------------------------------------------------------------------------------");
            log.finest(XML.toString(output, false));
            log.finest("--------------------------------------------------------------------------------");
        }
*/
        return output;
    }

    protected Document transformReferences(Document input, Context context) {

        Map<Element, Anchor> xrefs = findAnchors(input, Constants.TYPE_XREF);
        List<Element> citationElements = findElements(input, Constants.WRAPPER_ELEMENT_NAME, Constants.TYPE_CITATION);

        for (Map.Entry<Element, Anchor> entry : xrefs.entrySet()) {
            Element xrefElement = entry.getKey();
            Anchor xref = entry.getValue();

            // We have to try both schemes because {@link} just specifies the class/method and not the scheme
            String javadocXrefTargetIdentifier = xref.getAddress().toIdentifierString();
            String javacodeXrefTargetIdentifier  =
                    new AnchorAddress(
                            Scheme.JAVACODE,
                            xref.getAddress().getPath(),
                            xref.getAddress().getFragment()
                    ).toIdentifierString();

            log.finest("Trying to resolve xref: " + javadocXrefTargetIdentifier);
            Element resolvedCitationElement = resolveXref(citationElements, javadocXrefTargetIdentifier);

            if (resolvedCitationElement == null) {
                log.fine("Could not resolve xref, trying: " + javadocXrefTargetIdentifier);
                resolvedCitationElement = resolveXref(citationElements, javacodeXrefTargetIdentifier);
            }

            if (resolvedCitationElement != null) {
                String citationIdentifier = resolvedCitationElement.getAttribute(Constants.ATTR_ID);

                // Set new address (HREF) on xref element
                xrefElement.setAttribute(
                        Constants.ATTR_ADDRESS,
                        "#" + citationIdentifier
                );

                // If it doesn't have a label, set a label
                if (!xrefElement.hasChildNodes()) {
                    String citationLabel = getResolvedLabel(xref, resolvedCitationElement);
                    xrefElement.setTextContent(citationLabel != null ? citationLabel : getResolvedLabel(xref));
                }

            } else {
                log.warning("Linked citation identifier not found: " + javadocXrefTargetIdentifier + "/" + javacodeXrefTargetIdentifier);

                // Clean up and set a message that makes unresolved links easy to see
                XML.removeChildren(xrefElement);
                xrefElement.setAttribute(
                        Constants.ATTR_ADDRESS,
                        getUnresolvedLink(xref)
                );
                xrefElement.setAttribute(
                        Constants.ATTR_TYPE,
                        Constants.TYPE_XREF + " " + Constants.TYPE_UNRESOLVED
                );
                xrefElement.setTextContent(getUnresolvedLabel(xref));
            }

        }
        return input;
    }

    protected Element resolveXref(List<Element> citationElements, String xrefTargetIdentifier) {
        Element resolvedCitationElement = null;
        for (Element citationElement : citationElements) {
            String citationIdentifier = citationElement.getAttribute(Constants.ATTR_ID);
            if (xrefTargetIdentifier.equals(citationIdentifier)) {
                resolvedCitationElement = citationElement;
                break;
            }
        }
        return resolvedCitationElement;
    }

    protected String getResolvedLabel(Anchor xref) {
        return "(LINK)";
    }

    protected String getResolvedLabel(Anchor xref, Element citationElement) {
        // Try to find a direct child element that has a 'title' attribute, then take that content as label
        NodeList children = citationElement.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() != Node.ELEMENT_NODE) continue;
            Element element = (Element) child;
            String[] types = element.getAttribute(Constants.ATTR_TYPE).split(" ");
            for (String t : types) {
                if (t.trim().equals(Constants.TYPE_TITLE)) {
                    String title = element.getTextContent();
                    // TODO: And cut off that last period of the 'first sentence' title
                    return title.endsWith(".") ? title.substring(0, title.length() - 1) : title;
                }
            }
        }
        return null;
    }

    protected String getUnresolvedLink(Anchor xref) {
        return "#UNRESOLVED_LINK";
    }

    protected String getUnresolvedLabel(Anchor xref) {
        return "UNRESOLVED ID: " + xref.getAddress().toIdentifierString();
    }
}
